#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>

// Include important header files needed to interface with Outpost 2
#include "..\Outpost2DLL\Outpost2DLL.h"
// Include header files to make it easier to build levels
#include "..\OP2Helper\OP2Helper.h"

// Include base layout data
// Note: Editing this file is a good way to build bases.
#include "BaseData.h"

// www.wiki.outpost-universe.net/Icewld01
// www.wiki.outpost-universe.net/Ice_Plains
// v0.2
// ml2_p1.dll

char MapName[]			= "icewld01.map";							// The .map file used for this level
char LevelDesc[]		= "2P, LoS, 'icewld01 - Ice Plains' v0.2";			// Description appearing in the game list box
char TechtreeName[]		= "MULTITEK.TXT";						// File to use for the tech tree
SDescBlock DescBlock	= { MultiLastOneStanding, 2, 12, 0 };	// Important level details

BOOL APIENTRY DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	if (fdwReason == DLL_PROCESS_ATTACH) 
	{
		DisableThreadLibraryCalls(hinstDLL);
	}

    return TRUE;
}

int InitProc()
{
	int i;

	// Randomize starting locations
	RandomizeStartingLocationsWithSF(autosize(startLocation), playerFacLoc);

	//Create other mines
	CreateBeacons(numof(extraSet), extraSet);
	// Place all bases on the map
	for (i = 0; i < TethysGame::NoPlayers(); i++)
	{	
		/*
		InitPlayerResources(i);

 		//Normal
 		StartLocation &sLoc = startLocation[i];

 		// Make it a Plymouth base instead
		if (!Player[i].IsEden()) {
			StartLocation &sLoc = startLocation[i+4];
 		}
		*/
		//*
		InitPlayerResources(i);

		StartLocation &sLoc = startLocation[i];

		CreateBase(i, sLoc.x, sLoc.y, *sLoc.baseInfo);
		Player[i].CenterViewOn(sLoc.x, sLoc.y);

		Player[i].MarkResearchComplete(3401);	// Cybernetic Teleoperation
		Player[i].MarkResearchComplete(3305);	// Research Training Programs
		Player[i].MarkResearchComplete(3304);	// Offspring Enhancement
		Player[i].MarkResearchComplete(3303);	// Health Maintenance

		Unit factory;
		TethysGame::CreateUnit(factory, mapStructureFactory, playerFacLoc[i], i, mapNone, 0);
		factory.SetFactoryCargo(0, mapTokamak,			mapNone);
		factory.SetFactoryCargo(1, mapNursery,			mapNone);
		factory.SetFactoryCargo(2, mapUniversity,		mapNone);
		factory.SetFactoryCargo(3, mapVehicleFactory,	mapNone);
		factory.SetFactoryCargo(4, mapRobotCommand,		mapNone);
		factory.SetFactoryCargo(5, mapResidence,		mapNone);

	}


	// Misc initialization
	//TethysGame::CreateWreck(95, 63, (map_id)11999, 0); // Tech #11999 - tiger speed upgrade

	TethysGame::ForceMoraleGood(-1);
	if (TethysGame::UsesMorale())
		TethysGame::FreeMoraleLevel(-1);
	TethysGame::SetDaylightEverywhere(TethysGame::UsesDayNight() == 0);
	TethysGame::SetDaylightMoves(0);
	GameMap::SetInitialLightLevel(-32);

	//CreateLastOneStandingVictoryCondition();

	return 1; // return 1 if OK; 0 on failure

}

void AIProc() 
{
}

void __cdecl GetSaveRegions(struct BufferDesc &bufDesc)
{
	bufDesc.bufferStart = 0;	// Pointer to a buffer that needs to be saved
	bufDesc.length = 0;			// sizeof(buffer)
}


int StatusProc()
{
	return 0; // must return 0
}

SCRIPT_API void NoResponseToTrigger()
{
}


