
#include "..\OP2Helper\OP2Helper.h"

// Used to make autosizing the arrays easier
#define numof(array) (sizeof(array)/sizeof(array[0]))
// Used to make specifying the size of the array and the array easier
#define autosize(array) numof(array), array


//Dont use Beacon for Bases.
struct BeaconInfo beaconSet1[1]; 

struct BeaconInfo beaconSet2[1]; 

struct BeaconInfo beaconSet3[1]; 

struct BeaconInfo beaconSet4[1]; 

//Base Offset Cords - Corners
int base0x = 32;
int base0y = 0;
int base1x = 159;
int base1y = 62; 

//SF Cords Releative to Offset Base Cords
int sf0x =   13;
int sf0y =   2;
int sf1x =  -12;
int sf1y =  -2;

// i is variable to set the rare mines common so you can c them in game when testing.
int i = 1;

struct BeaconInfo extraSet[] =
{
	// Base Common Mines
	{ XYPos(  9,  7), mapMiningBeacon, 0, 1, 1},
	{ XYPos(126, 61), mapMiningBeacon, 0, 1, 1},

	/*
	// Outside Base Common Mines
	{ XYPos( 35, 16), mapMiningBeacon, 0, 1, 0},
	{ XYPos( 93, 48), mapMiningBeacon, 0, 1, 0},

	*/
	// 2nd Base Common Mines
	{ XYPos( 15, 40), mapMiningBeacon, 0, 1, 0},
	{ XYPos(114, 23), mapMiningBeacon, 0, 1, 0},
	// 2nd Base Rare Mines
	{ XYPos(  2, 40), mapMiningBeacon, i, 2, 1},
	{ XYPos(127, 23), mapMiningBeacon, i, 2, 1},
	// Side (3rd Base) Common Mines
	{ XYPos( 43, 57), mapMiningBeacon, 0, 1, 1},
	{ XYPos( 87,  7), mapMiningBeacon, 0, 1, 1},
	// Side Rare Mines
	{ XYPos( 62,  6), mapMiningBeacon, i, 1, 0},
	{ XYPos( 66, 58), mapMiningBeacon, i, 1, 0},
};

struct BuildingInfo buildingSet1[] = 
{
	{ +25,+2, mapCommandCenter		},
	{ +8, +2, mapCommonOreSmelter	},
	{ +32, +2, mapTokamak			},
	{ +21,+2, mapStandardLab		},
	{ +17,+2, mapAgridome			}
};

struct BuildingInfo buildingSet2[] = 
{
	{ -25,  -1, mapCommandCenter},
	//{-7, -10, mapStructureFactory},
	{-7,  -2, mapCommonOreSmelter},
	{ -31,  -1, mapTokamak},
	{ -21, -1, mapStandardLab},
	{ -17,  -1, mapAgridome}
};


struct TubeWallInfo tubeSet1[] = 
{
	{+3,  +2, +5,  +2},	// SM to Corner
	{+3,  +3, +3,  +12},	// Corner to Corner
	{+3,  +13, +12,  +13}	// Corner to GP
};

struct TubeWallInfo tubeSet2[] = 
{
	{-2, -13,  -10, -13}, // Corner to GP
	{-7, -4,  -7, -6},	// SM to Corner
	{-3, -6,  -6, -6},
	{-2, -6,  -2, -12}		// 
};

struct VehicleInfo unitSet1[] = 
{
	{  +15, +5, mapConVec,			mapNone,		0},
	{  +13, +5, mapConVec,			mapNone,		0},
	{  +11, +5, mapConVec,			mapNone,		0},
	{  +2, +15, mapCargoTruck,		mapNone,		0},
	{  +4, +15, mapCargoTruck,		mapNone,		0},
	{  +6, +15, mapCargoTruck,		mapNone,		0},
	{ +5,  +9, mapRoboSurveyor,	mapNone,		7},
	{ +3,  +11, mapRoboMiner,		mapNone,		7},
	{  +25, +5, mapEarthworker,		mapNone,		0},
	{ +12, +14, mapGuardPost,		mapMicrowave,	0}
};

struct VehicleInfo unitSet2[] = 
{
	{  -15,  -5, mapConVec,			mapNone,	 West},
	{  -13,  -5, mapConVec,			mapNone,	 West},
	{  -11,  -5, mapConVec,			mapNone,	 West},
	{  -1, -15, mapCargoTruck,		mapNone,	 West},
	{  -3, -15, mapCargoTruck,		mapNone,	 West},
	{  -5, -15, mapCargoTruck,		mapNone,	 West},
	{ -5,  -5, mapRoboSurveyor,	mapNone,		1},
	{ -7,  -7, mapRoboMiner,		mapNone,		1},
	{ -25,  -5, mapEarthworker,		mapNone,	 West},
	{ -10, -14, mapGuardPost,		mapMicrowave,	0}
}; 

struct BaseInfo base[] = 
{
	{ 0, 0, autosize(buildingSet1), autosize(tubeSet1), 0, 0, autosize(unitSet1) },
	{ 0, 0, autosize(buildingSet2), autosize(tubeSet2), 0, 0, autosize(unitSet2) },
};

struct StartLocation startLocation[] = 
{
	{ base0x, base0y, &base[0]},
	{ base1x, base1y, &base[1]}
};

struct LOCATION playerFacLoc[] =
{
	LOCATION( base0x + sf0x, base0y + sf0y),
	LOCATION( base1x + sf1x, base1y + sf1y),
};
